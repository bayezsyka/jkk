@extends('layouts.app')
@section('content')
    @include('sections-welcome.hero')
    @include('sections-welcome.why-us')
    @include('sections-welcome.about-us')
    @include('sections-welcome.our-services')
@endsection
