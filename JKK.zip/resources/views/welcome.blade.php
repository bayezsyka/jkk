@extends('layouts.app')
@section('content')
    @include('sections-welcome.hero')
    @include('sections-welcome.about-us')
    @include('sections-welcome.why-us')
    @include('sections-welcome.featured-services')
    @include('sections-welcome.featured-projects')
@endsection
